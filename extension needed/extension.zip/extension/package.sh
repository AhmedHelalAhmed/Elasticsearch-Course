#!/bin/bash
zip -r "$1" icons kb lib src favicon.ico *.html manifest.json sense.css