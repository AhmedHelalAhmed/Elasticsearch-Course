## Contributing

- First : thank you for contributing to this project !

- Fork the project
- Commit your changes on your fork
- Make a pull request


## Commit and PR message :

We use the [conventional changelog angular](https://github.com/conventional-changelog/conventional-changelog/tree/master/packages/conventional-changelog-angular) for commit message and PR title.